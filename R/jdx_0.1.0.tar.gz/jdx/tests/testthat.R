library(testthat)
library(jdx)

test_check("jdx")
