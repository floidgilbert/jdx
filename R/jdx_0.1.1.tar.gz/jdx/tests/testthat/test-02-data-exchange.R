# library(testthat)
# library(jdx)

# Comprehensive data testing is done in the jsr223 package, instead of here, for
# a two reasons. First, the tests are much easier to write with the help of
# JavaScript. Second, many of the tests were developed before jdx was separated
# from jsr223.
# 
# Some jdx data testing is included in the tests folder above the R project folder.
#


